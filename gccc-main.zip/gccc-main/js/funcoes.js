function sair(){
    window.location.href = 'sair.php';
}