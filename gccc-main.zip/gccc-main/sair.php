<?php 
    setcookie('user');
    header ("location: login.php");
?>