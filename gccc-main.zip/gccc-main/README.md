# gccc
Scripts para facilitar o serviço do GCCC
